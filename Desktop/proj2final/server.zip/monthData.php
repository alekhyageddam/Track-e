<?php
/*****************************************
** File:    monthData.php
** Project: CSCE 315 Project 1
** Date:    03/30/2018
**
** This file converts the results from MonthChart.php
** to a JSON representation.
**
***********************************************/
include('Partials.php');
include('Actions.php');

extract($_POST);
list($result, $resultCounts) = GetMonthData($startDate, $endDate);

echo json_encode($result);
?>