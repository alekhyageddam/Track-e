<?php
/*****************************************
** File:    weekData.php
** Project: CSCE 315 Project 1
** Date:    03/30/2018
**
** This file converts the results from WeekChart.php
** to a JSON representation.
**
***********************************************/
include('Partials.php');
include('Actions.php');

extract($_POST);
list($result, $resultCounts) = GetWeekData($startDate, $endDate);

$result = json_encode($result); //result is a JSON string
echo $result;

?>