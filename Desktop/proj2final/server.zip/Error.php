<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    include("DayChart.php");


    // $logger = new Logger();
    // $logger->info('Test log');
    // $logger->error('Test log');
?>