<?php
/*****************************************
** File:    dayData.php
** Project: CSCE 315 Project 1
** Date:    03/30/2018
**
** This file converts the results from DayChart.php
** to a JSON representation.
**
***********************************************/
include('Partials.php');
include('Actions.php');

extract($_POST);
list($result, $resultCounts) = GetDayData($startDate, $endDate);

$output = json_encode($result); //result is a JSON string
echo $output;

?>


